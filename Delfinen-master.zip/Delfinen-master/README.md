# [![Application icon](https://github.com/cph-mn521/Delfinen/blob/master/src/files/images/delfin.jpg)][icon]
[icon]: https://github.com/cph-mn521/Delfinen/blob/master/src/files/images/delfin.jpg


Delfinen is a piece of software written in java, that manages a sportsclubs members, economy and results.
by BBW software
